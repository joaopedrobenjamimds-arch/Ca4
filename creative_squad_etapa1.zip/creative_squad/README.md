# Creative Squad 4 - Reliquias Lendarias

MC 26.1.2 | Fabric Loader 0.19.5 | Fabric API 0.155.0+26.1.2 | Java 25

Reliquias sao ITENS VANILLA marcados com Data Component (custom_data.creative_squad_relic).
Nao ha itens, blocos, texturas nem modelos novos. Clientes vanilla conseguem entrar no servidor.

Obter: /cs4 give @s <id|all>   (ids: /cs4 list)
Compilar: gradle wrapper --gradle-version 9.2.1 ; ./gradlew build
