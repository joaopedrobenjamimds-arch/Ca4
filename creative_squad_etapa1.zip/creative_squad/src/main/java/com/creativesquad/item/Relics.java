package com.creativesquad.item;

import com.creativesquad.config.ModConfig;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.Unit;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;

/**
 * Reliquias = itens VANILLA marcados com um Data Component (custom_data.creative_squad_relic = "<id>").
 * Nenhum Item/Block novo e registrado: o mod pode rodar so no servidor e clientes vanilla entram normalmente.
 * A identidade NUNCA depende do nome do item.
 */
public final class Relics {
    public static final String KEY = "creative_squad_relic";

    private record Def(String id, Item base, String name, String lore, int color, boolean unbreakable) {}

    private static final List<Def> DEFS = List.of(
            new Def("lampiao_lendario", Items.LANTERN, "Lampião Lendário", "Quem o segura caminha sem ser visto.", 0xFFC107, false),
            new Def("bota_lendaria", Items.GOLDEN_BOOTS, "Bota Lendária", "Rápida como o vento.", 0x2196F3, true),
            new Def("relogio_lendario", Items.CLOCK, "Relógio Lendário", "Disfarce e teletransporte.", 0x9C27B0, false),
            new Def("escudo_lendario", Items.SHIELD, "Escudo Lendário", "Agache para repelir quem se aproxima.", 0x607D8B, true),
            new Def("tridente_lendario", Items.TRIDENT, "Tridente Lendário", "Indestrutível. Drena a força de quem atinge.", 0x00BCD4, true),
            new Def("capacete_gemeo_1", Items.GOLDEN_HELMET, "Capacete dos Gêmeos I", "Só desperta ao lado do seu irmão.", 0xE91E63, true),
            new Def("capacete_gemeo_2", Items.GOLDEN_HELMET, "Capacete dos Gêmeos II", "Só desperta ao lado do seu irmão.", 0x3F51B5, true),
            new Def("bussola_lendaria", Items.COMPASS, "Bússola Lendária", "Aponta para quem você procura.", 0x4CAF50, false),
            new Def("espada_lendaria", Items.GOLDEN_SWORD, "Espada Lendária do Caçador", "Indestrutível. Um golpe e o alvo voa longe.", 0xFFD700, true),
            new Def("pocao_lendaria", Items.SPLASH_POTION, "Poção Lendária", "Nunca acaba.", 0xF44336, false),
            new Def("cabeca_dragao", Items.DRAGON_HEAD, "Cabeça de Dragão Lendária", "Agache e liberte o fogo do dragão.", 0x673AB7, false),
            new Def("picareta_amaldicoada", Items.DIAMOND_PICKAXE, "Picareta Amaldiçoada", "Cava como nenhuma outra, mas se desgasta.", 0x795548, false),
            new Def("batata_lendaria", Items.POTATO, "Batata Lendária do Bobo", "Não subestime a batata.", 0xCDDC39, false),
            new Def("pena_lendaria", Items.FEATHER, "Pena Lendária", "Leve como o ar.", 0xFFFFFF, false));

    private Relics() {}

    public static List<String> ids() {
        return DEFS.stream().map(Def::id).toList();
    }

    public static boolean exists(String id) {
        return DEFS.stream().anyMatch(d -> d.id().equals(id));
    }

    /** Cria o item vanilla com a marca da reliquia. Precisa de registries para encantamentos. */
    public static ItemStack create(String id, HolderLookup.Provider registries) {
        Def d = DEFS.stream().filter(x -> x.id().equals(id)).findFirst().orElseThrow();
        ModConfig cfg = ModConfig.get();
        ItemStack stack = new ItemStack(d.base());

        CompoundTag tag = new CompoundTag();
        tag.putString(KEY, d.id());
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));

        stack.set(DataComponents.CUSTOM_NAME,
                Component.literal(d.name()).withStyle(s -> s.withColor(d.color()).withItalic(false)));
        stack.set(DataComponents.LORE, new ItemLore(List.of(
                Component.literal(d.lore()).withStyle(s -> s.withColor(d.color()).withItalic(false)))));
        stack.set(DataComponents.RARITY, Rarity.EPIC);

        if (d.unbreakable()) {
            stack.set(DataComponents.UNBREAKABLE, Unit.INSTANCE);
        }
        if (cfg.relicGlint) {
            stack.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
        }

        switch (d.id()) {
            case "tridente_lendario" -> enchant(stack, registries, Enchantments.CHANNELING, 1);
            case "espada_lendaria" -> enchant(stack, registries, Enchantments.KNOCKBACK, 10);
            case "picareta_amaldicoada" -> {
                enchant(stack, registries, Enchantments.EFFICIENCY, cfg.pickaxeEfficiency);
                stack.set(DataComponents.MAX_DAMAGE, cfg.pickaxeDurability);
            }
            case "pocao_lendaria" -> {
                int dur = cfg.potionDurationSeconds * 20;
                stack.set(DataComponents.POTION_CONTENTS, PotionContents.EMPTY
                        .withEffectAdded(new MobEffectInstance(MobEffects.STRENGTH, dur, cfg.potionStrengthLevel))
                        .withEffectAdded(new MobEffectInstance(MobEffects.REGENERATION, dur, cfg.potionRegenerationLevel))
                        .withEffectAdded(new MobEffectInstance(MobEffects.RESISTANCE, dur, cfg.potionResistanceLevel)));
            }
            default -> {}
        }
        return stack;
    }

    private static void enchant(ItemStack stack, HolderLookup.Provider registries,
                                ResourceKey<Enchantment> key, int level) {
        Holder<Enchantment> holder = registries.lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(key);
        stack.enchant(holder, level);
    }

    /** Id da reliquia do stack ("" se nao for reliquia). */
    public static String idOf(ItemStack stack) {
        if (stack.isEmpty()) return "";
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        if (data == null) return "";
        return data.copyTag().getStringOr(KEY, "");
    }

    public static boolean is(ItemStack stack, String relicId) {
        return idOf(stack).equals(relicId);
    }

    public static boolean isRelic(ItemStack stack) {
        return !idOf(stack).isEmpty();
    }
}
