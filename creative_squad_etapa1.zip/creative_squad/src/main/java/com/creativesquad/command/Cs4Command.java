package com.creativesquad.command;

import com.creativesquad.ability.CompassAbility;
import com.creativesquad.config.ModConfig;
import com.creativesquad.item.Relics;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.HolderLookup;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public final class Cs4Command {
    private Cs4Command() {}

    /** Somente operadores. */
    private static final Predicate<CommandSourceStack> ADMIN = Commands.hasPermission(Commands.LEVEL_GAMEMASTERS);

    private static final SuggestionProvider<CommandSourceStack> RELIC_IDS = (ctx, builder) -> {
        List<String> ids = new ArrayList<>(Relics.ids());
        ids.add("all");
        return SharedSuggestionProvider.suggest(ids, builder);
    };

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("cs4")
                .then(Commands.literal("give").requires(ADMIN)
                        .then(Commands.argument("jogador", EntityArgument.players())
                                .then(Commands.literal("all").executes(Cs4Command::giveAll))
                                .then(Commands.argument("reliquia", StringArgumentType.word())
                                        .suggests(RELIC_IDS)
                                        .executes(Cs4Command::giveOne))))
                .then(Commands.literal("list").requires(ADMIN).executes(Cs4Command::list))
                .then(Commands.literal("reload").requires(ADMIN).executes(Cs4Command::reload))
                .then(Commands.literal("debug").requires(ADMIN).executes(Cs4Command::debug))
                .then(Commands.literal("setroom").requires(ADMIN).executes(Cs4Command::setRoom))
                .then(Commands.literal("room").requires(ADMIN).executes(Cs4Command::room))
                // Bussola: qualquer jogador pode configurar a propria bussola
                .then(Commands.literal("compass")
                        .then(Commands.literal("nearest").executes(ctx -> {
                            CompassAbility.setNearest(ctx.getSource().getPlayerOrException());
                            ctx.getSource().sendSuccess(() -> Component.literal("Bussola: jogador mais proximo."), false);
                            return 1;
                        }))
                        .then(Commands.literal("off").executes(ctx -> {
                            CompassAbility.off(ctx.getSource().getPlayerOrException());
                            ctx.getSource().sendSuccess(() -> Component.literal("Bussola desligada."), false);
                            return 1;
                        }))
                        .then(Commands.literal("target")
                                .then(Commands.argument("jogador", EntityArgument.player()).executes(ctx -> {
                                    ServerPlayer target = EntityArgument.getPlayer(ctx, "jogador");
                                    CompassAbility.setTarget(ctx.getSource().getPlayerOrException(), target);
                                    ctx.getSource().sendSuccess(() -> Component.literal("Bussola rastreando ")
                                            .append(target.getDisplayName()), false);
                                    return 1;
                                })))));
    }

    private static int giveAll(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        Collection<ServerPlayer> targets = EntityArgument.getPlayers(ctx, "jogador");
        HolderLookup.Provider reg = ctx.getSource().registryAccess();
        for (ServerPlayer p : targets) {
            for (String rid : Relics.ids()) give(p, Relics.create(rid, reg));
        }
        ctx.getSource().sendSuccess(() -> Component.literal(
                "Entregues " + Relics.ids().size() + " itens (13 reliquias) para " + targets.size() + " jogador(es)."), true);
        return targets.size();
    }

    private static int giveOne(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        String id = StringArgumentType.getString(ctx, "reliquia");
        if (!Relics.exists(id)) {
            ctx.getSource().sendFailure(Component.literal("Reliquia desconhecida: " + id + ". Use /cs4 list."));
            return 0;
        }
        Collection<ServerPlayer> targets = EntityArgument.getPlayers(ctx, "jogador");
        for (ServerPlayer p : targets) {
            give(p, Relics.create(id, ctx.getSource().registryAccess()));
        }
        ctx.getSource().sendSuccess(() -> Component.literal(
                "Entregue " + id + " para " + targets.size() + " jogador(es)."), true);
        return targets.size();
    }

    private static int list(CommandContext<CommandSourceStack> ctx) {
        StringBuilder sb = new StringBuilder("Reliquias:");
        Relics.ids().forEach(rid -> sb.append("\n - ").append(rid));
        ctx.getSource().sendSuccess(() -> Component.literal(sb.toString()), false);
        return Relics.ids().size();
    }

    private static int reload(CommandContext<CommandSourceStack> ctx) {
        ModConfig.load();
        ctx.getSource().sendSuccess(() -> Component.literal(
                "Config recarregada. (Vale para itens novos entregues a partir de agora.)"), true);
        return 1;
    }

    /** Diagnostico: mostra qual reliquia o item da mao principal e (ou se nao e nenhuma). */
    private static int debug(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        String id = Relics.idOf(p.getMainHandItem());
        ctx.getSource().sendSuccess(() -> Component.literal(id.isEmpty()
                ? "O item na mao principal NAO e uma reliquia (sem marca). Use /cs4 give."
                : "Reliquia detectada na mao principal: " + id), false);
        return 1;
    }

    private static int setRoom(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
        ServerPlayer p = ctx.getSource().getPlayerOrException();
        ModConfig cfg = ModConfig.get();
        cfg.roomSet = true;
        cfg.roomDimension = p.level().dimension().identifier().toString();
        cfg.roomX = p.getX();
        cfg.roomY = p.getY();
        cfg.roomZ = p.getZ();
        cfg.roomYaw = p.getYRot();
        cfg.roomPitch = p.getXRot();
        ModConfig.save();
        ctx.getSource().sendSuccess(() -> Component.literal("Sala secreta definida na sua posicao atual."), true);
        return 1;
    }

    private static int room(CommandContext<CommandSourceStack> ctx) {
        ModConfig cfg = ModConfig.get();
        String msg = cfg.roomSet
                ? String.format("Sala secreta: %s  X=%.1f Y=%.1f Z=%.1f", cfg.roomDimension, cfg.roomX, cfg.roomY, cfg.roomZ)
                : "Sala secreta nao definida. Use /cs4 setroom.";
        ctx.getSource().sendSuccess(() -> Component.literal(msg), false);
        return 1;
    }

    private static void give(ServerPlayer player, ItemStack stack) {
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
    }
}
