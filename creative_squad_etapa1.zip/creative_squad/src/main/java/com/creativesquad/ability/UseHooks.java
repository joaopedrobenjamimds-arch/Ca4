package com.creativesquad.ability;

import com.creativesquad.config.ModConfig;
import com.creativesquad.item.Relics;
import java.util.Set;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Relative;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrownSplashPotion;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Botao direito: Relogio (teleporte) e Pocao (uso infinito). 100% servidor. */
public final class UseHooks {
    private UseHooks() {}

    public static void register() {
        UseItemCallback.EVENT.register((player, level, hand) -> {
            if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
            if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer sp)) return InteractionResult.PASS;

            String id = Relics.idOf(sp.getMainHandItem());
            if (id.isEmpty()) return InteractionResult.PASS;
            MinecraftServer server = sl.getServer();
            int now = server.getTickCount();

            switch (id) {
                case "relogio_lendario" -> {
                    if (!Cooldowns.tryUse(sp.getUUID(), "clock", now, 1)) return InteractionResult.SUCCESS;
                    teleportToRoom(server, sp);
                    return InteractionResult.SUCCESS;
                }
                case "pocao_lendaria" -> {
                    if (!Cooldowns.tryUse(sp.getUUID(), "potion", now, 1)) return InteractionResult.SUCCESS;
                    usePotion(sl, sp, sp.getMainHandItem());
                    return InteractionResult.SUCCESS; // cancela o consumo vanilla: a pocao nunca acaba
                }
                default -> { return InteractionResult.PASS; }
            }
        });
    }

    private static void teleportToRoom(MinecraftServer server, ServerPlayer p) {
        ModConfig cfg = ModConfig.get();
        if (!cfg.roomSet) {
            p.sendSystemMessage(Component.literal("A sala secreta ainda nao foi definida. Um operador deve usar /cs4 setroom."));
            return;
        }
        ResourceKey<Level> dim = ResourceKey.create(Registries.DIMENSION, Identifier.parse(cfg.roomDimension));
        ServerLevel target = server.getLevel(dim);
        if (target == null) {
            p.sendSystemMessage(Component.literal("Dimensao da sala secreta invalida: " + cfg.roomDimension));
            return;
        }
        p.teleportTo(target, cfg.roomX, cfg.roomY, cfg.roomZ, Set.<Relative>of(), cfg.roomYaw, cfg.roomPitch, true);
    }

    /**
     * Botao direito = ARREMESSA um projetil de Splash Potion vanilla (cai, explode em area e aplica os efeitos
     * pelo proprio codigo vanilla, controlado pelo servidor). O stack NAO e tocado, entao a pocao nunca acaba.
     * Agachado + botao direito = bebe (efeitos em si mesmo).
     */
    private static void usePotion(ServerLevel sl, ServerPlayer p, ItemStack held) {
        ModConfig cfg = ModConfig.get();
        if (p.isShiftKeyDown()) {
            applyPotion(p, cfg, cfg.potionDurationSeconds * 20);
            sl.sendParticles(ParticleTypes.WITCH, p.getX(), p.getY() + 1.0, p.getZ(), 20, 0.5, 0.5, 0.5, 0.05);
            return;
        }
        ThrownSplashPotion potion = new ThrownSplashPotion(sl, p, held.copyWithCount(1));
        potion.shootFromRotation(p, p.getXRot(), p.getYRot(), -20.0F, 0.5F, 1.0F);
        sl.addFreshEntity(potion);
    }

    private static void applyPotion(LivingEntity e, ModConfig cfg, int dur) {
        e.addEffect(new MobEffectInstance(MobEffects.STRENGTH, dur, cfg.potionStrengthLevel));
        e.addEffect(new MobEffectInstance(MobEffects.REGENERATION, dur, cfg.potionRegenerationLevel));
        e.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, dur, cfg.potionResistanceLevel));
    }
}
