package com.creativesquad.ability;

import com.creativesquad.config.ModConfig;
import com.creativesquad.item.Relics;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/**
 * Habilidades passivas (100% servidor). Roda a cada 10 ticks (nao a cada tick).
 * Em vez de "aplicar e lembrar de remover", aplica um efeito CURTO (30 ticks), ambiente e sem particulas,
 * renovado a cada 10 ticks. Ao largar a reliquia o efeito some sozinho em ate 1,5s e tambem e removido na hora,
 * sem tocar em efeitos de outras fontes (que tem duracao maior ou nao sao ambiente).
 */
public final class PassiveAbilities {
    private static final int INTERVAL = 10;
    private static final int DURATION = 30;

    private static final Map<UUID, Set<String>> ACTIVE = new HashMap<>();
    private static final Set<UUID> TWINS_ACTIVE = new HashSet<>();

    private PassiveAbilities() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(PassiveAbilities::onTick);
    }

    private static void onTick(net.minecraft.server.MinecraftServer server) {
        if (server.getTickCount() % INTERVAL != 0) return;
        List<ServerPlayer> players = server.getPlayerList().getPlayers();
        if (players.isEmpty()) {
            ACTIVE.clear();
            TWINS_ACTIVE.clear();
            return;
        }
        ModConfig cfg = ModConfig.get();
        List<ServerPlayer> twin1 = new ArrayList<>();
        List<ServerPlayer> twin2 = new ArrayList<>();
        Set<UUID> online = new HashSet<>();

        for (ServerPlayer p : players) {
            online.add(p.getUUID());

            boolean boots = Relics.is(p.getItemBySlot(EquipmentSlot.FEET), "bota_lendaria");
            sync(p, "boots", boots, MobEffects.SPEED, cfg.bootsSpeedLevel);

            boolean feather = holding(p, "pena_lendaria");
            sync(p, "feather", feather, MobEffects.SLOW_FALLING, 0);

            boolean omen = cfg.swordBadOmen && holding(p, "espada_lendaria");
            sync(p, "omen", omen, MobEffects.BAD_OMEN, 0);

            ItemStack head = p.getItemBySlot(EquipmentSlot.HEAD);
            if (Relics.is(head, "capacete_gemeo_1")) twin1.add(p);
            else if (Relics.is(head, "capacete_gemeo_2")) twin2.add(p);
        }

        // Gemeos: so ativa quando existe pelo menos um de CADA capacete em jogadores online.
        Set<UUID> twinNow = new HashSet<>();
        if (!twin1.isEmpty() && !twin2.isEmpty()) {
            List<ServerPlayer> all = new ArrayList<>(twin1);
            all.addAll(twin2);
            for (ServerPlayer p : all) {
                twinNow.add(p.getUUID());
                sync(p, "twinsRes", true, MobEffects.RESISTANCE, cfg.twinsResistanceLevel);
                sync(p, "twinsRegen", true, MobEffects.REGENERATION, cfg.twinsRegenerationLevel);
                if (TWINS_ACTIVE.add(p.getUUID())) {
                    p.sendSystemMessage(Component.literal("A conexao dos Gemeos foi ativada!"));
                }
            }
        }
        for (ServerPlayer p : players) {
            if (!twinNow.contains(p.getUUID())) {
                sync(p, "twinsRes", false, MobEffects.RESISTANCE, 0);
                sync(p, "twinsRegen", false, MobEffects.REGENERATION, 0);
                TWINS_ACTIVE.remove(p.getUUID());
            }
        }

        ACTIVE.keySet().retainAll(online);
        TWINS_ACTIVE.retainAll(online);
    }

    private static boolean holding(ServerPlayer p, String relicId) {
        return Relics.is(p.getMainHandItem(), relicId) || Relics.is(p.getOffhandItem(), relicId);
    }

    private static void sync(ServerPlayer p, String key, boolean on, Holder<MobEffect> effect, int amp) {
        Set<String> set = ACTIVE.computeIfAbsent(p.getUUID(), k -> new HashSet<>());
        if (on) {
            // ambient=true, visible(particulas)=false, showIcon=true
            p.addEffect(new MobEffectInstance(effect, DURATION, amp, true, false, true));
            set.add(key);
        } else if (set.remove(key)) {
            MobEffectInstance cur = p.getEffect(effect);
            if (cur != null && cur.isAmbient() && cur.getDuration() <= DURATION) {
                p.removeEffect(effect);
            }
        }
    }
}
