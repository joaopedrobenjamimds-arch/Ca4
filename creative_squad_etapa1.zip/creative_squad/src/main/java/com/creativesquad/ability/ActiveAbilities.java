package com.creativesquad.ability;

import com.creativesquad.config.ModConfig;
import com.creativesquad.item.Relics;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.hurtingprojectile.DragonFireball;
import net.minecraft.world.phys.Vec3;

/**
 * Habilidades ao AGACHAR (Escudo e Cabeca de Dragao). 100% servidor.
 * Dispara apenas na transicao "nao agachado -> agachado" (nao repete segurando SHIFT).
 * So olha o inventario de quem acabou de agachar, entao e barato.
 */
public final class ActiveAbilities {
    private static final Set<UUID> SNEAKING = new HashSet<>();

    private ActiveAbilities() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(ActiveAbilities::onTick);
    }

    private static void onTick(MinecraftServer server) {
        int tick = server.getTickCount();
        if (tick % 2 != 0) return;
        ModConfig cfg = ModConfig.get();

        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            UUID id = p.getUUID();
            if (!p.isShiftKeyDown()) {
                SNEAKING.remove(id);
                continue;
            }
            if (!SNEAKING.add(id)) continue; // ja estava agachado: ignora

            if (Relics.is(p.getOffhandItem(), "escudo_lendario")
                    && Cooldowns.tryUse(id, "shield", tick, cfg.shieldCooldown)) {
                shockwave(p, cfg);
            }
            if (hasDragonHead(p) && Cooldowns.tryUse(id, "dragon", tick, cfg.dragonHeadCooldown)) {
                fireball(p);
            }
        }
        if (tick % 200 == 0) {
            Set<UUID> online = new HashSet<>();
            server.getPlayerList().getPlayers().forEach(pl -> online.add(pl.getUUID()));
            SNEAKING.retainAll(online);
        }
    }

    private static boolean hasDragonHead(ServerPlayer p) {
        return Relics.is(p.getMainHandItem(), "cabeca_dragao")
                || Relics.is(p.getOffhandItem(), "cabeca_dragao")
                || Relics.is(p.getItemBySlot(EquipmentSlot.HEAD), "cabeca_dragao");
    }

    /** Onda de impacto: so empurra (sem dano, sem destruir blocos, nao afeta o usuario). */
    private static void shockwave(ServerPlayer p, ModConfig cfg) {
        if (!(p.level() instanceof ServerLevel sl)) return;
        double r = cfg.shieldRadius;
        for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class,
                p.getBoundingBox().inflate(r), x -> x != p && x.isAlive())) {
            Vec3 d = e.position().subtract(p.position());
            double dist = Math.sqrt(d.x * d.x + d.z * d.z);
            if (dist > r) continue;
            double nx = dist < 1.0E-4 ? 1.0 : d.x / dist;
            double nz = dist < 1.0E-4 ? 0.0 : d.z / dist;
            double strength = cfg.shieldKnockback * (1.0 - 0.5 * dist / r);
            e.setDeltaMovement(e.getDeltaMovement().add(nx * strength, 0.5, nz * strength));
            e.hurtMarked = true; // forca o servidor a enviar a nova velocidade ao cliente
        }
        sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, p.getX(), p.getY() + 1.0, p.getZ(), 1, 0, 0, 0, 0);
        sl.sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 0.2, p.getZ(), 60, r * 0.4, 0.1, r * 0.4, 0.1);
    }

    private static void fireball(ServerPlayer p) {
        if (!(p.level() instanceof ServerLevel sl)) return;
        Vec3 look = p.getLookAngle();
        DragonFireball fb = new DragonFireball(sl, p, look);
        fb.setPos(p.getX() + look.x * 1.5, p.getEyeY() - 0.3 + look.y * 1.5, p.getZ() + look.z * 1.5);
        sl.addFreshEntity(fb);
    }
}
