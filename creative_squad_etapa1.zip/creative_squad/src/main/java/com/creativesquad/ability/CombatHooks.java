package com.creativesquad.ability;

import com.creativesquad.config.ModConfig;
import com.creativesquad.item.Relics;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/** Efeitos ao ATINGIR outro jogador (corpo a corpo). 100% servidor. */
public final class CombatHooks {
    private CombatHooks() {}

    public static void register() {
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            if (level.isClientSide()) return InteractionResult.PASS;
            if (!(entity instanceof ServerPlayer target) || target == player) return InteractionResult.PASS;

            String id = Relics.idOf(player.getMainHandItem());
            if (id.isEmpty()) return InteractionResult.PASS;
            ModConfig cfg = ModConfig.get();

            switch (id) {
                case "tridente_lendario" -> target.addEffect(new MobEffectInstance(
                        MobEffects.MINING_FATIGUE, cfg.tridentMiningFatigueDuration, cfg.tridentMiningFatigueLevel));
                case "batata_lendaria" -> {
                    target.addEffect(new MobEffectInstance(
                            MobEffects.POISON, cfg.potatoPoisonDuration, cfg.potatoPoisonLevel));
                    target.addEffect(new MobEffectInstance(
                            MobEffects.SLOWNESS, cfg.potatoSlownessDuration, cfg.potatoSlownessLevel));
                }
                default -> { }
            }
            return InteractionResult.PASS; // deixa o dano vanilla acontecer
        });
    }
}
