package com.creativesquad.ability;

import com.creativesquad.config.ModConfig;
import com.creativesquad.item.Relics;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.GlobalPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.LodestoneTracker;

/**
 * Bussola Lendaria: usa o componente vanilla LODESTONE_TRACKER (sem bloco de lodestone),
 * entao a agulha vanilla aponta sozinha. Atualiza a cada compassUpdateTicks, so para quem segura a bussola.
 */
public final class CompassAbility {
    private record Mode(boolean nearest, UUID target) {}

    private static final Map<UUID, Mode> MODES = new HashMap<>();
    private static final Set<UUID> WARNED = new HashSet<>();

    private CompassAbility() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(CompassAbility::onTick);
    }

    public static void setNearest(ServerPlayer p) {
        MODES.put(p.getUUID(), new Mode(true, null));
        WARNED.remove(p.getUUID());
    }

    public static void setTarget(ServerPlayer p, ServerPlayer target) {
        MODES.put(p.getUUID(), new Mode(false, target.getUUID()));
        WARNED.remove(p.getUUID());
    }

    public static void off(ServerPlayer p) {
        MODES.remove(p.getUUID());
        WARNED.remove(p.getUUID());
        for (ItemStack s : new ItemStack[] {p.getMainHandItem(), p.getOffhandItem()}) {
            if (Relics.is(s, "bussola_lendaria")) s.remove(DataComponents.LODESTONE_TRACKER);
        }
    }

    private static void onTick(MinecraftServer server) {
        int interval = Math.max(1, ModConfig.get().compassUpdateTicks);
        if (server.getTickCount() % interval != 0 || MODES.isEmpty()) return;

        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            Mode mode = MODES.get(p.getUUID());
            if (mode == null) continue;

            ItemStack stack = Relics.is(p.getMainHandItem(), "bussola_lendaria") ? p.getMainHandItem()
                    : Relics.is(p.getOffhandItem(), "bussola_lendaria") ? p.getOffhandItem() : null;
            if (stack == null) continue;

            ServerPlayer target = mode.nearest() ? nearest(server, p) : server.getPlayerList().getPlayer(mode.target());
            if (target == null) {
                if (WARNED.add(p.getUUID())) {
                    p.sendSystemMessage(Component.literal("Alvo da bussola indisponivel."));
                }
                continue;
            }
            WARNED.remove(p.getUUID());
            LodestoneTracker tracker = new LodestoneTracker(
                    Optional.of(GlobalPos.of(target.level().dimension(), target.blockPosition())), false);
            if (!tracker.equals(stack.get(DataComponents.LODESTONE_TRACKER))) {
                stack.set(DataComponents.LODESTONE_TRACKER, tracker);
            }
        }
    }

    private static ServerPlayer nearest(MinecraftServer server, ServerPlayer p) {
        ServerPlayer best = null;
        double bestDist = Double.MAX_VALUE;
        for (ServerPlayer o : server.getPlayerList().getPlayers()) {
            if (o == p || o.level() != p.level()) continue;
            double d = p.distanceToSqr(o);
            if (d < bestDist) {
                bestDist = d;
                best = o;
            }
        }
        return best;
    }
}
