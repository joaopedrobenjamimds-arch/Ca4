package com.creativesquad.ability;

import com.creativesquad.item.Relics;
import com.mojang.datafixers.util.Pair;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Holder;
import net.minecraft.network.protocol.game.ClientboundSetEquipmentPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

/**
 * Lampiao Lendario - furtividade, SOMENTE no servidor (nenhum mod no cliente necessario).
 *
 * Tecnica: enquanto o jogador segura o lampiao, o servidor envia aos OUTROS jogadores um pacote
 * ClientboundSetEquipmentPacket com todos os slots VAZIOS para a entidade dele. Clientes vanilla
 * passam a renderizar o jogador sem armadura nem itens. O proprio jogador nunca recebe esse pacote,
 * entao continua se vendo normalmente. O pacote e reenviado a cada 10 ticks (o vanilla reenvia o
 * equipamento real quando algo muda; pode haver um piscar de ate 0,5s). Ao soltar o lampiao, o
 * equipamento real e reenviado.
 *
 * Particulas: efeitos reais NAO sao removidos; so e ligado o modo "sem particulas" e restaurado depois.
 */
public final class StealthAbility {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
            EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND};

    private static final Set<UUID> HIDDEN = new HashSet<>();
    private static final Map<UUID, Set<Holder<MobEffect>>> HIDDEN_EFFECTS = new HashMap<>();

    private StealthAbility() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(StealthAbility::onTick);
    }

    private static void onTick(MinecraftServer server) {
        if (server.getTickCount() % 10 != 0) return;
        List<ServerPlayer> players = server.getPlayerList().getPlayers();
        if (players.isEmpty()) {
            HIDDEN.clear();
            HIDDEN_EFFECTS.clear();
            return;
        }
        Set<UUID> online = new HashSet<>();
        for (ServerPlayer p : players) {
            UUID id = p.getUUID();
            online.add(id);
            boolean holding = Relics.is(p.getMainHandItem(), "lampiao_lendario")
                    || Relics.is(p.getOffhandItem(), "lampiao_lendario");
            if (holding) {
                HIDDEN.add(id);
                broadcastEquipment(players, p, true);
                hideParticles(p);
            } else if (HIDDEN.remove(id)) {
                broadcastEquipment(players, p, false);
                restoreParticles(p);
            }
        }
        HIDDEN.retainAll(online);
        HIDDEN_EFFECTS.keySet().retainAll(online);
    }

    private static void broadcastEquipment(List<ServerPlayer> players, ServerPlayer owner, boolean hide) {
        List<Pair<EquipmentSlot, ItemStack>> list = new ArrayList<>();
        for (EquipmentSlot s : SLOTS) {
            list.add(Pair.of(s, hide ? ItemStack.EMPTY : owner.getItemBySlot(s).copy()));
        }
        ClientboundSetEquipmentPacket packet = new ClientboundSetEquipmentPacket(owner.getId(), list);
        for (ServerPlayer other : players) {
            if (other == owner || other.level() != owner.level()) continue; // nunca para o proprio dono
            if (other.distanceToSqr(owner) > 128.0 * 128.0) continue;
            other.connection.send(packet);
        }
    }

    private static void hideParticles(ServerPlayer p) {
        Set<Holder<MobEffect>> changed = HIDDEN_EFFECTS.computeIfAbsent(p.getUUID(), k -> new HashSet<>());
        for (MobEffectInstance inst : new ArrayList<>(p.getActiveEffects())) {
            if (!inst.isVisible()) continue;
            Holder<MobEffect> eff = inst.getEffect();
            MobEffectInstance hidden = new MobEffectInstance(
                    eff, inst.getDuration(), inst.getAmplifier(), inst.isAmbient(), false, inst.showIcon());
            p.removeEffect(eff);
            p.addEffect(hidden);
            changed.add(eff);
        }
    }

    private static void restoreParticles(ServerPlayer p) {
        Set<Holder<MobEffect>> changed = HIDDEN_EFFECTS.remove(p.getUUID());
        if (changed == null) return;
        for (Holder<MobEffect> eff : changed) {
            MobEffectInstance inst = p.getEffect(eff);
            if (inst == null) continue;
            MobEffectInstance shown = new MobEffectInstance(
                    eff, inst.getDuration(), inst.getAmplifier(), inst.isAmbient(), true, inst.showIcon());
            p.removeEffect(eff);
            p.addEffect(shown);
        }
    }
}
