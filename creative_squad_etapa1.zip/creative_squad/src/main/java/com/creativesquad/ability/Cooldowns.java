package com.creativesquad.ability;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Cooldown por jogador+habilidade, em ticks de servidor (sem timers nem entidades). */
public final class Cooldowns {
    private static final Map<String, Integer> NEXT = new HashMap<>();

    private Cooldowns() {}

    /** true (e inicia o cooldown) se a habilidade estiver liberada. */
    public static boolean tryUse(UUID player, String key, int nowTick, int cooldownSeconds) {
        String k = player + ":" + key;
        Integer next = NEXT.get(k);
        if (next != null && nowTick < next) return false;
        NEXT.put(k, nowTick + Math.max(0, cooldownSeconds) * 20);
        return true;
    }
}
