package com.creativesquad;

import com.creativesquad.ability.ActiveAbilities;
import com.creativesquad.ability.CombatHooks;
import com.creativesquad.ability.CompassAbility;
import com.creativesquad.ability.PassiveAbilities;
import com.creativesquad.ability.StealthAbility;
import com.creativesquad.ability.UseHooks;
import com.creativesquad.command.Cs4Command;
import com.creativesquad.config.ModConfig;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Entrypoint comum (roda no servidor dedicado, no singleplayer e no cliente). */
public class CreativeSquadMod implements ModInitializer {
    public static final String MOD_ID = "creative_squad";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        // A config precisa carregar ANTES do registro (durabilidade da picareta depende dela).
        ModConfig.load();
        PassiveAbilities.register();
        CombatHooks.register();
        UseHooks.register();
        ActiveAbilities.register();
        CompassAbility.register();
        StealthAbility.register();

        CommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess, environment) -> Cs4Command.register(dispatcher));

        LOGGER.info("Creative Squad 4 carregado (reliquias sao itens vanilla marcados).");
    }
}
