package com.creativesquad.config;

import com.creativesquad.CreativeSquadMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;

/** config/creative_squad.json. Niveis sao "amplifier" (0 = nivel I, 4 = nivel V). Tempos em ticks (20 = 1s) salvo indicado. */
public class ModConfig {
    // Bota
    public int bootsSpeedLevel = 4;
    // Escudo
    public double shieldRadius = 8.0;
    public int shieldCooldown = 5; // segundos
    public double shieldKnockback = 2.0;
    // Cabeca de dragao
    public int dragonHeadCooldown = 5; // segundos
    public double dragonHeadDamage = 10.0;
    public double dragonHeadRange = 40.0;
    // Bussola
    public int compassUpdateTicks = 10;
    // Tridente
    public int tridentMiningFatigueLevel = 2;
    public int tridentMiningFatigueDuration = 300;
    // Espada
    public double swordDamage = 8.0;
    public boolean swordBadOmen = true;
    // Pocao
    public int potionStrengthLevel = 1;
    public int potionRegenerationLevel = 1;
    public int potionResistanceLevel = 1;
    public int potionDurationSeconds = 30;
    // Capacetes dos gemeos
    public int twinsResistanceLevel = 0;
    public int twinsRegenerationLevel = 0;
    // Batata
    public int potatoPoisonLevel = 1;
    public int potatoPoisonDuration = 200;
    public int potatoSlownessLevel = 5;
    public int potatoSlownessDuration = 100;
    // Picareta (valem para picaretas NOVAS entregues pelo /cs4 give)
    public int pickaxeDurability = 2031;
    public int pickaxeEfficiency = 10;
    // Brilho de encantamento nas reliquias
    public boolean relicGlint = true;
    // Sala secreta (Relogio)
    public boolean roomSet = false;
    public String roomDimension = "minecraft:overworld";
    public double roomX = 0, roomY = 100, roomZ = 0;
    public float roomYaw = 0, roomPitch = 0;
    // Bussola (estado)
    public String compassMode = "off"; // off | nearest | target
    public String compassTarget = "";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static ModConfig instance = new ModConfig();

    public static ModConfig get() {
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("creative_squad.json");
    }

    public static void load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                ModConfig loaded = GSON.fromJson(r, ModConfig.class);
                if (loaded != null) instance = loaded;
            } catch (Exception e) {
                CreativeSquadMod.LOGGER.error("Falha ao ler {}; usando padroes.", p, e);
                instance = new ModConfig();
            }
        }
        instance.sanitize();
        save(); // regrava para adicionar campos novos
    }

    public static void save() {
        try {
            Files.createDirectories(path().getParent());
            try (Writer w = Files.newBufferedWriter(path(), StandardCharsets.UTF_8)) {
                GSON.toJson(instance, w);
            }
        } catch (IOException e) {
            CreativeSquadMod.LOGGER.error("Falha ao salvar config.", e);
        }
    }

    private void sanitize() {
        bootsSpeedLevel = Math.max(0, Math.min(255, bootsSpeedLevel));
        shieldRadius = Math.max(1.0, shieldRadius);
        shieldCooldown = Math.max(0, shieldCooldown);
        dragonHeadCooldown = Math.max(0, dragonHeadCooldown);
        compassUpdateTicks = Math.max(1, compassUpdateTicks);
        pickaxeDurability = Math.max(1, pickaxeDurability);
        if (compassMode == null) compassMode = "off";
        if (compassTarget == null) compassTarget = "";
        if (roomDimension == null) roomDimension = "minecraft:overworld";
    }
}
